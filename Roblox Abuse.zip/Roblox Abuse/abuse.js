const noblox = require('noblox.js');

// Group and rank configuration
const GROUP_ID = 515698; // Replace with your group ID
const CURRENT_RANK_ID = 64544980; // Replace with the rank ID to find users
const NEW_RANK_ID = 106364860; // Replace with the rank ID to assign
const COOKIE = '_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_CAEaAhAB.2D8BECBF9BDD7B7E4C557CA7738A9F534B9235C39DFC102BA026748BF3898494F61962A3351AE0F01D84B0E679439472F4CF1A760A7868E15A82DA6250C6A78E415D72D627C8EC4ABBB3C8A9339C86CBFB08B2B38461A96FC6B3513FA7C145EDDA99F9A3FB09AB90472E5103C38AD4E35954E16C9CAAA9AD6BC403564B14F9F09EFE1A20BA33CA49745855B6631E667253D6442420DFFC52039CB23DC93EABD234CB1192FF78B193C14C9461E9A5E70353829648E5CD00B296568E9CB44038C29A97D6E6355599428C058A6C1B9AD0936D7BD8F61647F3547C6ABD80B9278E8AD9735A427B4B088A1D02DEE8C2FF5D3DEBC8DEBCEE902E70DCA25351E8D15DDD17AE1EFA713DCE508DB14583CD11F580323EBF17A66E69EDA1F61F77B38EDC738263878FB036F14A13978FE0CC39516C562BDCD5B027F2D1639ABDA8D688CB6D30A4B45BEECFF406F88AB1DA0D5713539F4D0359F64059403E4F90B15CA13CD36E5C6F199174B8C023F4CC335BEC7678762D3710A092FC08989F8C78A3FD700C9C2CFACAA2E10868A1EFEFC3C0119FE2E16D638A88052BBD29E76EBC07B11937FD6FBD51F86A9243D137C9CF78A5DBE79B878548DDF1FF8FF8834603A67215232175C3D0C396EFD9D17C3934CA6D45F23A4C72795F079BD4A582A7F35F94122281F6630C08671C1622DF7C5EC54DFB57881A44F3F9C160DC4BAD2997E211069A27792F9B794F109010B99C708DCF95FE5FB816E06BE46B35158F25EEB035A44784EA0440F8D2195A9E1533608062AD9F3BD7102988405C5B82D83EF14592B608824EDDDE83A9A5B70CAA782816ED7FE81BBBEC7F0669FF32EBB19C5394B9A4CCEC8526334922061CD1BB8AE3ED927855C3C88978694EEA460F69C2FBCAD75BCDF4CEEDB032CEF81E852B3C5578B1392E49A48D4C4F991BB2CFF23A6A6E879D7F89D2E7122FD67AB0F0C9762C66803BA0B5A7B9403D35D71BCD08BBAFCCA691577E48807DC83EBE15D0DD07A2AB8DA0C36579AAC0DBBFC101B1B24777B05D2EC979CE363CBFFBE68CE0F81423CE6B0AC614359E302C5ACD42EDFE470D0BD22D7D1B195049EBEF8BFBCBAD1A57834DD43E86C387B262F41F04F463A101A98473D5A86DBD582B15A7B93C7C0194917E54868C0A7A1A6D593F301C5D729DA1C517394FCA7010682C777FCAF745FDA05B7DBCC4F38F38C08CA2CDE7967E50D71EA11E607F4D0F'; // Replace with your Roblox cookie

// Helper function to sleep (wait) for a certain amount of time
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Helper function to retry a function on failure
async function retryOperation(fn, retries = 3, delay = 2000) {
    let attempt = 0;
    while (attempt < retries) {
        try {
            return await fn();
        } catch (error) {
            attempt++;
            console.error(`Attempt ${attempt} failed: ${error.message}`);
            if (attempt < retries) {
                console.log(`Retrying in ${delay / 1000} seconds...`);
                await sleep(delay);
            } else {
                throw new Error(`All retries failed: ${error.message}`);
            }
        }
    }
}

// Main function to rank users
async function rankUsers() {
    try {
        // Log into Roblox
        await noblox.setCookie(COOKIE);
        console.log('Logged into Roblox successfully.');

        let page = 1; // Start from the first page
        let totalUsers = 0; // Counter to keep track of total users processed

        while (true) {
            // Fetch users in batches of 100 (max allowed by noblox)
            const members = await retryOperation(() => noblox.getPlayers(GROUP_ID, CURRENT_RANK_ID, { page }));
            if (members.length === 0) break; // No more users, exit the loop

            console.log(`Fetched page ${page} with ${members.length} users.`);

            // Process users in parallel with rate limiting
            const batchSize = 3000; // Number of parallel requests per batch (adjust to balance speed and rate limits)
            const userPromises = [];

            for (let i = 0; i < members.length; i++) {
                const userId = members[i].userId;
                // Add the rank update action to the promise array
                userPromises.push(
                    retryOperation(() => noblox.setRank(GROUP_ID, userId, NEW_RANK_ID)).then(() => {
                        console.log(`Ranked user ${userId}.`);
                        totalUsers++;
                    }).catch(error => {
                        console.error(`Failed to rank user ${userId}: ${error.message}`);
                    })
                );

                // If we reached the batch size, wait for the batch to finish
                if (userPromises.length >= batchSize) {
                    await Promise.all(userPromises);
                    userPromises.length = 0; // Clear the array for the next batch
                    console.log(`Batch of ${batchSize} users processed. Total users ranked so far: ${totalUsers}`);
                    // Sleep to respect rate limits (adjust the delay as needed)
                    await sleep(2000); // Wait for 2 seconds
                }
            }

            // If there are any remaining users in the current batch, process them
            if (userPromises.length > 0) {
                await Promise.all(userPromises);
                console.log(`Remaining users processed. Total users ranked so far: ${totalUsers}`);
            }

            page++; // Move to the next page
            await sleep(1000); // Sleep for 5 seconds between page fetches to avoid rate limits
        }

        console.log(`All users processed. Total users ranked: ${totalUsers}`);
    } catch (error) {
        console.error(`Error during execution: ${error.message}`);
    }
}

// Run the script
rankUsers();